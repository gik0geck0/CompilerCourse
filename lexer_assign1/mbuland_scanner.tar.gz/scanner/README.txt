1. Extract
2. cd scanner
3. make
4. cat <testfile> | ./capp
